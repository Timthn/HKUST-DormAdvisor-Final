# HKUST Undergraduate Hall Charges & HKUST Hall Room Availability Matrix (宿舍房型可用性矩陣)
本文档汇总了香港科技大学所有本科生宿舍的住宿费用，按四种学生类型分类。
费用以港币（HK$）计算，按学年收取。
> ⚠️ 推薦引擎必讀：此表為房型篩選的唯一依據。
> 若某組合標記為 ❌，則該宿舍絕對不可推薦給該類學生的該房型需求。

## New Local Undergraduate Students (新入學本地學生)

> hall_id 欄為推薦引擎輸出使用的字符串 ID，必須嚴格採用此 ID。

| hall_id | Hall Name | Single Room | Double Room | Triple Room | Bunk Bed Room |
|---------|-----------|:-----------:|:-----------:|:-----------:|:-------------:|
| "1"  | UG Hall I   | ❌ | ✅ $19,460 | ❌ | ❌ |
| "2"  | UG Hall II  | ❌ | ✅ $19,460 | ✅ $15,012 | ❌ |
| "3"  | UG Hall III | ❌ | ✅ $19,460 | ✅ $15,012 | ❌ |
| "4"  | UG Hall IV  | ❌ | ✅ $19,460 | ✅ $15,012 | ❌ |
| "5"  | UG Hall V   | ❌ | ❌ | ❌ | ✅ $15,568 |
| "6"  | UG Hall VI  | ❌ | ✅ $19,460 | ✅ $15,012 | ❌ |
| "7"  | UG Hall VII | ❌ | ✅ $23,630 | ❌ | ❌ |
| "8"  | UG Hall VIII| ❌ | ✅ $23,630 | ❌ | ❌ |
| "9"  | UG Hall IX  | ❌ | ✅ $23,630 | ❌ | ❌ |
| "10" | UG Hall X   | ❌ | ✅ $25,020 | ❌ | ❌ |
| "11" | UG Hall XI  | ❌ | ✅ $25,020 | ❌ | ❌ |
| "12" | UG Hall XII | ❌ | ✅ $25,020 | ❌ | ❌ |
| "13" | UG Hall XIII| ❌ | ✅ $25,020 | ❌ | ❌ |
| "JCH"| JCH         | ❌ | ✅ $25,576 | ❌ | ❌ |

**關鍵結論：新入學本地學生 (New Local UG) 不可入住 Single Room，任何宿舍均不提供。**

## Continuing Local Undergraduate Students (在學本地學生)

| hall_id | Hall Name | Single Room | Double Room | Triple Room | Bunk Bed Room |
|---------|-----------|:-----------:|:-----------:|:-----------:|:-------------:|
| "1"  | UG Hall I   | ❌ | ✅ $19,460 | ❌ | ❌ |
| "2"  | UG Hall II  | ❌ | ✅ $19,460 | ✅ $15,012 | ❌ |
| "3"  | UG Hall III | ❌ | ✅ $19,460 | ✅ $15,012 | ❌ |
| "4"  | UG Hall IV  | ❌ | ✅ $19,460 | ✅ $15,012 | ❌ |
| "5"  | UG Hall V   | ❌ | ❌ | ❌ | ✅ $15,568 |
| "6"  | UG Hall VI  | ❌ | ✅ $19,460 | ✅ $15,012 | ❌ |
| "7"  | UG Hall VII | ✅ $37,252 | ✅ $23,630 | ❌ | ❌ |
| "8"  | UG Hall VIII| ✅ $37,252 | ✅ $23,630 | ❌ | ❌ |
| "9"  | UG Hall IX  | ✅ $37,252 | ✅ $23,630 | ❌ | ❌ |
| "10" | UG Hall X   | ✅ $39,576 | ✅ $25,020 | ❌ | ❌ |
| "11" | UG Hall XI  | ✅ $39,576 | ✅ $25,020 | ❌ | ❌ |
| "12" | UG Hall XII | ✅ $39,576 | ✅ $25,020 | ❌ | ❌ |
| "13" | UG Hall XIII| ✅ $39,576 | ✅ $25,020 | ❌ | ❌ |
| "JCH"| JCH         | ❌ | ✅ $25,576 | ❌ | ❌ |

## New Non-Local Undergraduate Students (新入學非本地學生)

| hall_id | Hall Name | Single Room | Double Room | Triple Room | Bunk Bed Room |
|---------|-----------|:-----------:|:-----------:|:-----------:|:-------------:|
| "1"  | UG Hall I   | ❌ | ✅ $23,204 | ❌ | ❌ |
| "2"  | UG Hall II  | ❌ | ✅ $23,204 | ✅ $17,904 | ❌ |
| "3"  | UG Hall III | ❌ | ✅ $23,204 | ✅ $17,904 | ❌ |
| "4"  | UG Hall IV  | ❌ | ✅ $23,204 | ✅ $17,904 | ❌ |
| "5"  | UG Hall V   | ❌ | ❌ | ❌ | ✅ $18,564 |
| "6"  | UG Hall VI  | ❌ | ✅ $23,204 | ✅ $17,904 | ❌ |
| "7"  | UG Hall VII | ❌ | ✅ $28,172 | ❌ | ❌ |
| "8"  | UG Hall VIII| ❌ | ✅ $28,172 | ❌ | ❌ |
| "9"  | UG Hall IX  | ❌ | ✅ $28,172 | ❌ | ❌ |
| "10" | UG Hall X   | ❌ | ✅ $29,828 | ❌ | ❌ |
| "11" | UG Hall XI  | ❌ | ✅ $29,828 | ❌ | ❌ |
| "12" | UG Hall XII | ❌ | ✅ $29,828 | ❌ | ❌ |
| "13" | UG Hall XIII| ❌ | ✅ $29,828 | ❌ | ❌ |
| "JCH"| JCH         | ❌ | ✅ $30,504 | ❌ | ❌ |

**關鍵結論：新入學非本地學生 (New Non-Local UG) 不可入住 Single Room，任何宿舍均不提供。**

## Continuing Non-Local Undergraduate Students (在學非本地學生)

| hall_id | Hall Name | Single Room | Double Room | Triple Room | Bunk Bed Room |
|---------|-----------|:-----------:|:-----------:|:-----------:|:-------------:|
| "1"  | UG Hall I   | ❌ | ✅ $23,204 | ❌ | ❌ |
| "2"  | UG Hall II  | ❌ | ✅ $23,204 | ✅ $17,904 | ❌ |
| "3"  | UG Hall III | ❌ | ✅ $23,204 | ✅ $17,904 | ❌ |
| "4"  | UG Hall IV  | ❌ | ✅ $23,204 | ✅ $17,904 | ❌ |
| "5"  | UG Hall V   | ❌ | ❌ | ❌ | ✅ $18,564 |
| "6"  | UG Hall VI  | ❌ | ✅ $23,204 | ✅ $17,904 | ❌ |
| "7"  | UG Hall VII | ✅ $43,008 | ✅ $28,172 | ❌ | ❌ |
| "8"  | UG Hall VIII| ✅ $43,008 | ✅ $28,172 | ❌ | ❌ |
| "9"  | UG Hall IX  | ✅ $43,008 | ✅ $28,172 | ❌ | ❌ |
| "10" | UG Hall X   | ✅ $45,640 | ✅ $29,828 | ❌ | ❌ |
| "11" | UG Hall XI  | ✅ $45,640 | ✅ $29,828 | ❌ | ❌ |
| "12" | UG Hall XII | ✅ $45,640 | ✅ $29,828 | ❌ | ❌ |
| "13" | UG Hall XIII| ✅ $45,640 | ✅ $29,828 | ❌ | ❌ |
| "JCH"| JCH         | ❌ | ✅ $30,504 | ❌ | ❌ |
# HKUST Undergraduate Hall Facilities (宿舍设施详情)

本文档汇总了香港科技大学所有本科生宿舍的设施信息，按宿舍分类，
涵盖卧室、公共休息室、茶水间、浴室、洗衣房等设施的详细描述。

---

## UG Hall I (ughall1) Facilities

- **Hall Code**: ughall1
- **Inquiry Email**: ughi@ust.hk

### UG Hall I (ughall1) - Bedroom

All bedrooms in UG Hall I are fully furnished and air-conditioned. A room is shared by two students. A chair, a desk, a wardrobe, a shoe cabinet, a bookshelf, an internet outlet port and a bed with mattress are provided in the room for each resident. Electronic meters are installed for the air conditioners and residents are charged according to actual electricity consumption.

### UG Hall I (ughall1) - Common Room

There is a common room on each floor where residents can meet and socialize. Television, drinking fountain, refrigerator, microwave oven, newspapers and telephone are provided.

### UG Hall I (ughall1) - Pantry

A pantry is located beside the lift lobby. It is equipped with a sink, refrigerator and microwave oven. There are no cooking facilities in the pantry nor in any other areas in the hall premises.

### UG Hall I (ughall1) - Bathroom

Each floor has two toilets equipped with shower facilities. Hot water is provided.

### UG Hall I (ughall1) - Laundry

The laundry is shared with the residents living in Stephen Kam Chuen Cheong Hall and it is equipped with 10 washing machines and 10 drying machines. All are smart-card operated. Irons and ironing boards are provided upon request and subject to availability.

---

## UG Hall II (ughall2) Facilities

- **Hall Code**: ughall2
- **Inquiry Email**: ughii@ust.hk

### UG Hall II (ughall2) - Bedroom

There are two types of room in UG Hall II: Double Room Triple Room All bedrooms in UG Hall II are fully furnished and air-conditioned. A chair, a desk, a wardrobe, a bookshelf, internet outlet port and a bed with mattress are provided in the room for each resident. Electronic meters are installed for the air conditioners so that residents are charged according to actual electricity consumption.

### UG Hall II (ughall2) - Common Room

There is a common room on each floor where residents can meet and socialize. Television, refrigerator, microwave oven, newspapers and telephone are provided.

### UG Hall II (ughall2) - Pantry

A pantry, equipped with a sink, drinking fountain or water dispenser, a refrigerator, a microwave oven and an electric water boiler, is located beside the common room. There are no cooking facilities in the pantry nor in any other areas in the hall premises

### UG Hall II (ughall2) - Bathroom

Each floor has one toilet which equipped with shower facilities. Hot water is provided.

### UG Hall II (ughall2) - Laundry

The laundry is equipped with 5 washing machines and 5 drying machines. All are smartcard-operated. Irons and ironing boards are provided upon request and subject to availability.

---

## UG Hall III (ughall3) Facilities

- **Hall Code**: ughall3
- **Inquiry Email**: ughiii@ust.hk

### UG Hall III (ughall3) - Bedroom

There are two types of room in UG Hall III: Double Room Triple Room All bedrooms in UG Hall III are fully furnished and air-conditioned. A chair, a desk, a wardrobe, a bookshelf, an internet outlet port and a bed with mattress are provided in the room for each resident. Electronic meters are installed for the air conditioners so that residents are charged according to actual electricity consumption.

### UG Hall III (ughall3) - Common Room

There is a common room on each floor where residents can meet and socialize. Television, sofa, newspapers, 2 refrigerators and telephone are provided.

### UG Hall III (ughall3) - Pantry

A pantry, equipped with a sink, a drinking fountain and 2 microwave ovens, is located inside the common room. There are no cooking facilities in the pantry nor in any other areas in the hall premises

### UG Hall III (ughall3) - Bathroom

Each floor has two toilets which equipped with shower facilities. Hot water is provided.

### UG Hall III (ughall3) - Laundry

The laundry is equipped with 6 washing machines and 6 drying machines. All are smart card-operated. Irons and ironing boards are provided upon request and subject to availability.

---

## UG Hall IV (ughall4) Facilities

- **Hall Code**: ughall4
- **Inquiry Email**: ughiv@ust.hk

### UG Hall IV (ughall4) - Bedroom

There are two types of room in UG Hall IV: Double Room Triple Room All bedrooms in UG Hall IV are fully furnished and air-conditioned. A chair, a desk, a wardrobe, a bookshelf, internet outlet port and a bed with mattress are provided in the room for each resident. Electronic meters are installed for the air conditioners so that residents are charged according to actual electricity consumption.

### UG Hall IV (ughall4) - Common Room

There is a common room on each floor where residents can meet and socialize. Television, sofa, newspapers and telephone are provided.

### UG Hall IV (ughall4) - Pantry

A pantry, equipped with a sink, drinking fountain, a refrigerator, a microwave oven and an electric water boiler, is located beside the common room. There are no cooking facilities in the pantry nor in any other areas in the hall premises

### UG Hall IV (ughall4) - Bathroom

Each floor has two toilets which equipped with shower facilities. Hot water is provided.

### UG Hall IV (ughall4) - Laundry

The laundry is equipped with 6 washing machines and 6 drying machines. All are smart card/coin-operated. Irons and ironing boards are provided upon request and subject to availability.

---

## UG Hall V (ughall5) Facilities

- **Hall Code**: ughall5
- **Inquiry Email**: ughv@ust.hk

### UG Hall V (ughall5) - Bedroom

All bedrooms in the PG Hall II / UG Hall V are for double occupancy. Each room is furnished with a bunk-bed, chairs, desk, bookshelves, a wardrobe and a washing basin. An air-conditioner and internet outlet ports are provided.

### UG Hall V (ughall5) - Common Room

In PG Hall Il / UG Hall V, the pantry is designed next to the common room. There is a common room located in each wing of each floor where residents can meet and socialize. Television, refrigerators, drinking fountain, sofa, newspapers and telephones are provided.

### UG Hall V (ughall5) - Pantry

In PG Hall Il(UG Hall V), the pantry is designed next to the common room. A hot water boiler, a sink and a microwave oven are provided. The microwave oven is for re-heating and simple preparation of food only. There are no cooking facilities in the pantry nor any other areas in the hall.

### UG Hall V (ughall5) - Bathroom

There is one bathroom in each wing, each with 3 toilets and 3 showers. Hot water is provided in the showers.

### UG Hall V (ughall5) - Laundry

The laundry is equipped with 5 washing machines and 5 drying machines. All are smart card/coin-operated. Irons and ironing boards are provided upon request and subject to availability.

---

## UG Hall VI (ughall6) Facilities

- **Hall Code**: ughall6
- **Inquiry Email**: ughvi@ust.hk

### UG Hall VI (ughall6) - Bedroom

There are two types of room in UG Hall VI: Double Room Triple Room All bedrooms in UG Hall VI are fully furnished and air-conditioned. A chair, a desk, a wardrobe, a bookshelf, internet outlet port and a bed with mattress are provided in the room for each resident. Besides, there is a washing basin in each room. Electronic meters are installed for the air conditioners so that residents are charged according to actual electricity consumption.

### UG Hall VI (ughall6) - Common Room

In UG Hall Vl, the pantry is designed to be together with common room. There is a common room located in each wing of each floor where residents can meet and socialize. Television, sofa, newspapers and telephone are provided.

### UG Hall VI (ughall6) - Pantry

In UG Hall Vl, the pantry is designed to be together with common room. A pantry, equipped with a sink, drinking fountain, a refrigerator, a microwave oven and an electric water boiler, is located beside the common room. There are no cooking facilities in the pantry nor in any other areas in the hall premises

### UG Hall VI (ughall6) - Bathroom

There is one bathroom in each wing, each with 4 toilets and 4 showers. They are designed unisex. Hot water is provided in the showers.

### UG Hall VI (ughall6) - Laundry

The laundry is equipped with 6 washing machines and 6 drying machines. All are smart card/coin-operated. Irons and ironing boards are provided upon request and subject to availability.

---

## UG Hall VII (ughall7) Facilities

- **Hall Code**: ughall7
- **Inquiry Email**: ughvii@ust.hk

### UG Hall VII (ughall7) - Bedroom

There are two types of room in CSK Hall (UG Hall VII): Single Room Double Room All bedrooms in UG Hall VII are fully furnished and air-conditioned. A chair, a desk, a wardrobe, a bookshelf, an internet outlet port and a bed with mattress are provided in the room for each resident. Besides, a toilet and a bathroom are shared by 2 residents (in single rooms) and by 4 residents (in double rooms). Electronic meters are installed for the air conditioners so that residents are charged according to actual electricity consumption.

### UG Hall VII (ughall7) - Common Room

There are 2 Common Rooms on every residential floor of CSK Hall (UG Hall VII). Each Common Room is equipped with a sink, a drinking fountain, 2 refrigerators, 2 microwave ovens and an electric water boiler. There are no cooking facilities in the room or in any other areas in the hall premises.

### UG Hall VII (ughall7) - Laundry

The laundry is equipped with 4 washing and 4 drying machines. All are smart card operated. Irons and ironing boards are provided upon request and subject to availability.

---

## UG Hall VIII (ughall8) Facilities

- **Hall Code**: ughall8
- **Inquiry Email**: ughviii@ust.hk

### UG Hall VIII (ughall8) - Bedroom

There are two types of room in UG Hall VIII: Single Room in shared apartment They are 6 single bedrooms in each apartment. Bedrooms in shared apartment are fully furnished and air-conditioned. A chair, a desk, a wardrobe, a bookshelf, internet outlet port and a bed with mattress are provided in the room for each resident. Besides, a kitchen, a living room and a toilet with shower facilities are shared by the residents of the same apartments. Electronic meters are installed for the air conditioners so that residents are charged according to actual electricity consumption. Double Room Double rooms in UG Hall VIII are fully furnished and air-conditioned. A chair, a desk, a wardrobe, a bookshelf, internet outlet port and a bed with mattress are provided in the room for each resident. Besides, a toilet and a bathroom are shared by 4 residents (in double rooms). Electronic meters are installed for the air conditioners so that residents are charged according to actual electricity consumption.

### UG Hall VIII (ughall8) - Common Room

There is one Common Room on every residential floor of UG Hall VIII. Each Common Room is equipped with a sink, a drinking fountain, a refrigerator, a microwave oven. There are no cooking facilities in the room or in any other areas in the hall premises.

### UG Hall VIII (ughall8) - Laundry

A laundry room, used by residents of both UG Halls VIII and IX, is equipped with 10 washing machines and 10 drying machines. All are smartcard-operated. Irons and ironing boards are provided upon request and subject to availability.

---

## UG Hall IX (ughall9) Facilities

- **Hall Code**: ughall9
- **Inquiry Email**: ughix@ust.hk

### UG Hall IX (ughall9) - Bedroom

There are two types of room in UG Hall IX Single Room in shared apartment They are 6 single bedrooms in each apartment. Bedrooms in shared apartment are fully furnished and air-conditioned. A chair, a desk, a wardrobe, a bookshelf, internet outlet port and a bed with mattress are provided in the room for each resident. Besides, a kitchen, a living room and a toilet with shower facilities are shared by the residents of the same apartments. Electronic meters are installed for the air conditioners so that residents are charged according to actual electricity consumption. Double Room Double rooms in UG Hall IX are fully furnished and air-conditioned. A chair, a desk, a wardrobe, a bookshelf, internet outlet port and a bed with mattress are provided in the room for each resident. Besides, a toilet and a bathroom are shared by 4 residents (in double rooms). Electronic meters are installed for the air conditioners so that residents are charged according to actual electricity consumption.

### UG Hall IX (ughall9) - Common Room

There is one Common Room on every residential floor of UG Hall IX. Each Common Room is equipped with a sink, a drinking fountain, a refrigerator, a microwave oven. There are no cooking facilities in the room or in any other areas in the hall premises.

### UG Hall IX (ughall9) - Laundry

A laundry room, used by residents of both UG Halls VIII and IX, is equipped with 10 washingmachines and 10 drying machines. All are smartcard-operated. Irons and ironing boards are provided upon request and subject to availability.

---

## Jockey Club Hall (JCH) (ughall-jch) Facilities

- **Hall Code**: ughall-jch
- **Inquiry Email**: jch@ust.hk

### Jockey Club Hall (JCH) (ughall-jch) - Living Room & Bedroom

All bedrooms in JCH are fully furnished and air-conditioned. A chair, a desk, a wardrobe, a shoe cabinet, a bookshelf, an internet outlet port and a bed with mattress are provided to each resident. Electronic meters are installed for the air conditioners and residents are charged according to actual electricity consumption. Each apartment is equipped with a living room fully furnished with chairs, a sofa, a dining table, a coffee table, a refrigerator and a microwave oven. Residents can only use the microwave oven in the living room of the apartment and are not allowed to relocate it.  Cooking facilities are not provided, residents should prepare their own water boilers for drinking water, and bring their own portable induction stove for light cooking purposes.

### Jockey Club Hall (JCH) (ughall-jch) - Study Room & Kiosk

Residents enjoy the opportunity to buy with no waiting and no delay at our self-service Kiosk on G/F. Charged printing service is available. Study room on 5/F is available for residents’ use from 7:30am to 1am daily. (opening hours are subject to change without prior notice)

### Jockey Club Hall (JCH) (ughall-jch) - Bathroom

A pantry is located beside the lift lobby. It is equipped with a sink, refrigerator and microwave oven. There are no cooking facilities in the pantry nor in any other areas in the hall premises.

### Jockey Club Hall (JCH) (ughall-jch) - Laundry

Each apartment has two toilets and two shower rooms. Hot water is provided.

### Jockey Club Hall (JCH) (ughall-jch) - Basketball Court

The laundry is equipped with washing machines, dryers, ironing boards and a scale.

### Jockey Club Hall (JCH) (ughall-jch) - Sky Garden & Fitness Room

The basketball court in the open area of the Hall is available for use from 10:30am to 10:30pm daily. (opening hours are subject to change without prior notice)
